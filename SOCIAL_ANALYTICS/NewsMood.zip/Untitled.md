

```python
# ADD 3 OBSERVABLE TRENDS: 2018-03-23 21:48
# CNN is the media with worst value on sentiment analysis. Most of tweets are about school shootting in schools.
# CBS is the media with best value on sentiment analysis. Most of tweets are about sports, shows and movies.
# FOX and The New York times have many tweets that cannot be determined as positive or negative.
```


```python
# Dependencies
import tweepy
import json
import numpy as np
import pprint
import pandas as pd
import time
import matplotlib.pyplot as plt
import seaborn as sns

#Libray for sentiment analysis
from config import consumer_key,consumer_secret,access_token,access_token_secret
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
analyzer = SentimentIntensityAnalyzer()
```


```python
# Setup Tweepy API Authentication
auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_token_secret)
api = tweepy.API(auth, parser=tweepy.parsers.JSONParser())
```


```python
tweet_ls=[]
compound_ls=[]
positive_ls=[]
negative_ls=[]
neutral_ls=[]

# Target User
target_user = ["@BBC","@CBS","@CNN","@FOXTV","@nytimes"]


for user in target_user: 

    counter =1
    
    # Pagination (to get 100 tweets) 
    for x in range(5):

        # Get all tweets from home feed
        public_tweets = api.user_timeline(user)

           # Loop through all tweets
        for tweet in public_tweets:
            
             # Run Vader Analysis on each tweet
            compound = analyzer.polarity_scores(tweet["text"])["compound"]
            pos = analyzer.polarity_scores(tweet["text"])["pos"]
            neu = analyzer.polarity_scores(tweet["text"])["neu"]
            neg = analyzer.polarity_scores(tweet["text"])["neg"]
            tweets_ago = counter

            # Add sentiments for each tweet into an array
            tweet_ls.append({"Target": tweet["user"]["name"], 
                            "Tweet":tweet["text"],
                            "Date":tweet["created_at"],
                            "Compound": compound,
                            "Positive": pos,
                            "Negative": neu,
                            "Neutral": neg,
                            "Tweets Ago": counter})

            # Add to counter 
            counter = counter + 1

```


```python
# Convert sentiments to DataFrame
tweet_df = pd.DataFrame.from_dict(tweet_ls)

tweet_df.sort_values(by='Date', ascending=False)

tweet_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Compound</th>
      <th>Date</th>
      <th>Negative</th>
      <th>Neutral</th>
      <th>Positive</th>
      <th>Target</th>
      <th>Tweet</th>
      <th>Tweets Ago</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.000</td>
      <td>Fri Mar 23 19:07:00 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0</td>
      <td>BBC</td>
      <td>RT @BBCOne: .@GaryLineker, @OreOduba, @ThisisD...</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>-0.296</td>
      <td>Fri Mar 23 18:03:04 +0000 2018</td>
      <td>0.864</td>
      <td>0.136</td>
      <td>0.0</td>
      <td>BBC</td>
      <td>From @taylorswift13 to @Beyonce: these are the...</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.000</td>
      <td>Fri Mar 23 17:33:03 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0</td>
      <td>BBC</td>
      <td>Tonight, @GaryLineker, @ThisisDavina and @OreO...</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.000</td>
      <td>Fri Mar 23 17:02:01 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0</td>
      <td>BBC</td>
      <td>Your week, as told by @louistheroux. 📆😂\nhttps...</td>
      <td>4</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.000</td>
      <td>Fri Mar 23 16:27:45 +0000 2018</td>
      <td>1.000</td>
      <td>0.000</td>
      <td>0.0</td>
      <td>BBC</td>
      <td>RT @BBCWales: A #DanceForParkinsons session wi...</td>
      <td>5</td>
    </tr>
  </tbody>
</table>
</div>




```python
 # Save the DataFrame as a csv
tweet_df.to_csv("output/Sentiment_Analysis_Media_Data.csv",
                     encoding="utf-8", index=False)
```


```python
#Scatter plot
import datetime
now = datetime.datetime.now()
now=now.strftime("%Y-%m-%d %H:%M")

g=sns.lmplot('Tweets Ago', 'Compound', data=tweet_df, hue='Target', fit_reg=False, size=8,legend=True)

# title
g._legend.set_title('')

plt.xlabel("Tweets Ago")
plt.ylabel("Tweet Polarity")
plt.title(f"Sentiment Analysis of media tweets: {now}")

sns.set_style("darkgrid")

plt.xlim([0-5, 100+5])
plt.ylim([-1.00, 1.00])


# Show plot
plt.show()

# Save the figure
plt.savefig("output/SentimentAnalysis_Scatter.png")
```


![png](output_6_0.png)



    <matplotlib.figure.Figure at 0x26952955470>



```python
#Group by Target, aggregation average by Compound 
tweet_group_df = tweet_df.groupby(["Target"])['Compound'].agg(['mean']).sort_index().reset_index()
tweet_group_df = tweet_group_df.rename(columns={"mean":"Tweet Polarity"})
tweet_group_df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Target</th>
      <th>Tweet Polarity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BBC</td>
      <td>0.135335</td>
    </tr>
    <tr>
      <th>1</th>
      <td>CBS</td>
      <td>0.387445</td>
    </tr>
    <tr>
      <th>2</th>
      <td>CNN</td>
      <td>-0.121020</td>
    </tr>
    <tr>
      <th>3</th>
      <td>FOX</td>
      <td>0.223150</td>
    </tr>
    <tr>
      <th>4</th>
      <td>The New York Times</td>
      <td>0.055650</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Bar plot average values by media

sns.set_style("whitegrid")
ax = sns.barplot(x="Target", y="Tweet Polarity", data=tweet_group_df)


def autolabel(rects, labels=None, height_factor=1.05):
    for i, rect in enumerate(rects):
        height = rect.get_height()
        if labels is not None:
            try:
                label = labels[i]
            except (TypeError, KeyError):
                label = ' '
        else:
            label = '%d' % int(height)
        ax.text(rect.get_x() + rect.get_width()/2., height_factor*height,
                '{}'.format(label),
                ha='center', va='bottom')

autolabel(ax.patches, labels=round(tweet_group_df["Tweet Polarity"],2), height_factor=1.02)
plt.ylim([-0.25, 0.50])

plt.xlabel("")
plt.ylabel("Tweet Polarity")
plt.title(f"Overall Media Sentiment based on Twitter: {now}")

plt.show()

# Save the figure
plt.savefig("output/OverallMediaSentiment_Bar.png")
```


![png](output_8_0.png)



    <matplotlib.figure.Figure at 0x26952a32e48>

